def promedio(visitas)
    promedio_visitas = 0
    lenght = visitas.count
    visitas.each do |visita|
        promedio_visitas += visita/lenght
    end
    promedio_visitas
end

puts promedio([1000, 800 , 250, 300, 500, 2500])